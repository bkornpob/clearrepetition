# Clear Repetition

clearrepetition is a function to removing any repeating x. Precisely, for (x,y) if n(x) > 1, then remove all (x,y) and replace with one entry of (x, mean(y|x)).
